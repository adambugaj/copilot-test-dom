---
title: "Pierwszy wpis - Wprowadzenie"
description: "To jest przykładowy wpis pokazujący jak dodawać treści."
pubDate: "2025-12-01"
tags: ["start","astro","seo"]
---

Witaj! To jest przykładowy wpis. Możesz dodawać kolejne pliki `.md` do `src/content/posts/`.

Przykładowy akapit z listą:

- Punkt pierwszy
- Punkt drugi

Pamiętaj o dobrych praktykach SEO:
- unikalny tytuł i opis,
- odpowiednie nagłówki (h1..h3),
- optymalizacja obrazów (alternatywny tekst).